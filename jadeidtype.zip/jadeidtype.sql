prompt Importing table ldcode...
set feedback off
set define off
insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'E', 'Military ID', 'ʿ��֤/SOLDIER''S ID CARD', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'F', 'Military ID', '����֤/MILITARY OFFICER ID', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'I', 'National ID', '��������֤/IDENTITY CARDARY OFFICER ID', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'N', 'Military ID', '��װ��������֤/POLICEMAN ID CARD', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'P', 'Passport', '����/PASSPORT', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'U', 'Other ID', 'UNDEFINED ID TYPE', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'X', 'Pass_of_HK_MC_TW', '�۰�̨����ͨ��֤/PASS TO MAINLAND PRC', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'J', 'R_HK_MC_TW', '�۰�̨����ͨ��֤/PASS TO MAINLAND PRC', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'O', 'Other ID', '����', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'C', 'Birth Card', '����֤', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'K', 'PR', '��������þ���֤', null, null);

insert into ldcode (CODETYPE, CODE, CODENAME, CODEALIAS, COMCODE, OTHERSIGN)
values ('jadeidtype', 'H', 'Residence Book', '���ڱ�', null, null);

prompt Done.
