prompt Importing table ldtask...
set feedback off
set define off
insert into ldtask (TASKCODE, TASKNAME, TASKCONTROLLERPATH, TASKSTATUS, TASKRUNTIME, TASKDESC, TASKMODIFYDATE, TASKMODIFYTIME)
values ('007', 'jadePolicyTask', '/ExcelReportController/jadePolicyTask.do', 'N', '1:00:00', 'jade��������', null, null);

insert into ldtask (TASKCODE, TASKNAME, TASKCONTROLLERPATH, TASKSTATUS, TASKRUNTIME, TASKDESC, TASKMODIFYDATE, TASKMODIFYTIME)
values ('008', 'jadeResultTask', '/ExcelReportController/jadeResultTask.do', 'N', '2:00:00', 'jade���պ˱�', null, null);

insert into ldtask (TASKCODE, TASKNAME, TASKCONTROLLERPATH, TASKSTATUS, TASKRUNTIME, TASKDESC, TASKMODIFYDATE, TASKMODIFYTIME)
values ('009', 'jadeOverdueTask', '/ExcelReportController/jadeOverdueTask.do', 'N', '3:00:00', 'jade����', null, null);

insert into ldtask (TASKCODE, TASKNAME, TASKCONTROLLERPATH, TASKSTATUS, TASKRUNTIME, TASKDESC, TASKMODIFYDATE, TASKMODIFYTIME)
values ('010', 'hubHolidayTask', '/ExcelReportController/hubHolidayTask.do', 'N', '4:00:00', 'holiday����', null, null);

prompt Done.
