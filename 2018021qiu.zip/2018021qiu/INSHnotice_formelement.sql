prompt PL/SQL Developer import file
prompt Created on 2018��8��21�� by chen
set feedback off
set define off
prompt Deleting FORMELEMENT...
delete from FORMELEMENT where sid ='INSHnotice' and id like 'notice40%'  ;
prompt Loading FORMELEMENT...
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40', null, '���Ƿ��ѹ������ڻ�׼�������������չ�˾�����ٱ��ա������˺����ջ򽡿����գ������ǡ�����������', 'ParentElement', 'Have you bought or is currently buying or intending to buy life insurance; personal accident insurance or health insurance from another insurance company? If so, please describe.' || chr(10) || '', null, null, null, null, 'notice');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40a1', 'owneryesorno', 'Ͷ����', 'radio', null, 'notice_radio', null, 'noticeinfos', 'notice40', 'appntquestion');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40i1', 'insuredyesorno', '������', 'radio', null, 'notice_radio', null, 'noticeinfos', 'notice40', 'insuquestion');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q1', 'noticeinfo1', '���չ�˾����1', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q10', 'noticeinfo8', '��������3', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q11', 'noticeinfo9', '���ս��3', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q2', 'noticeinfo2', '��������1', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q3', 'noticeinfo3', '���ս��1', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q4', null, null, null, null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q5', 'noticeinfo4', '���չ�˾����2', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q6', 'noticeinfo5', '��������2', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q7', 'noticeinfo6', '���ս��2', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q8', null, null, null, null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('INSHnotice', 'notice40q9', 'noticeinfo7', '���չ�˾����3', 'text', null, null, null, 'noticelifeInsu', 'notice40', 'noticeInfo');
prompt 14 records loaded
set feedback on
set define on
prompt Done.
