prompt PL/SQL Developer import file
prompt Created on 2018��8��21�� by chen
set feedback off
set define off
prompt Deleting ELEMENTSOFCONTROL...
delete from ELEMENTSOFCONTROL where sid ='INSHnotice' and id like 'notice40%'  ;
prompt Loading ELEMENTSOFCONTROL...
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40', null, null, null, 115, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40a1', null, null, null, 117, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40i1', null, null, null, 116, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q1', null, null, null, 119, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q10', null, null, null, 128, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q11', null, null, null, 129, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q2', null, null, null, 120, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q3', null, null, null, 121, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q4', null, null, null, 122, '01', 'N/A', null, 'hidden');
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q5', null, null, null, 123, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q6', null, null, null, 124, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q7', null, null, null, 125, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q8', null, null, null, 126, '01', 'N/A', null, 'hidden');
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('INSHnotice', 'notice40q9', null, null, null, 127, '01', 'N/A', null, null);
prompt 14 records loaded
set feedback on
set define on
prompt Done.
