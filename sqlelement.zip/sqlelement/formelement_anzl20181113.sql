prompt PL/SQL Developer import file
prompt Created on 2018��11��13�� by chen
set feedback off
set define off
prompt Loading FORMELEMENT...
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredtwojade', 'jade', '����ͻ�', 'combobox', null, 'commonCombobox_jade', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'coveredlocalsociomedical1', 'coveredlocalsociomedical', '�������ҽ�Ʊ��ղα���Ա', 'combobox', null, 'commonCombobox_insuredsociomedical', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredcompany1', 'lcinsuredcompany', '������λ', null, null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'mobile1', 'mobile', '�ƶ��绰', null, null, null, null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'phone1', 'homephone', '�̶��绰', null, null, null, null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'email1', 'email', 'E-mail', null, null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredtype1', 'lcinsuredtype', '����������', 'combobox', null, 'commonCombobox_lcinsuredtype', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredindustry1', 'industrytype', '��ҵ���', 'combobox', null, 'commonCombobox_lcinsuredindustry', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredindustrycode1', 'occupationtype', '��ҵ����', 'combobox', null, 'commonCombobox_lcinsuredindustrycodemulti', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredbirthcounty1', 'lcinsuredbirthcounty', '�����˳����ع���', 'combobox', null, 'commonCombobox_country', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'insuredpostdistrict1', 'postdistrict', '��ַ��', 'combobox', null, 'commonCombobox_insuredpostdistrictmulti', null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'insuredpostprovince1', 'postprovince', '��ַʡ', 'combobox', null, 'commonCombobox_insuredpostprovince', null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredtwopostalflag', 'postalflags', 'ͬͶ���˵�ַ', 'checkbox', null, null, null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'relationtoappnt1', 'relatoinsu', '���һ�����˹�ϵ', 'combobox', null, 'commonCombobox_insuredrelaToInsu', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredname1', 'lcinsuredname', '����', null, null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredidtype1', 'lcinsuredidtype', '֤������', 'combobox', null, 'commonCombobox_IDtype', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredidno1', 'lcinsuredidno', '֤������', null, null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredsex1', 'lcinsuredsex', '�Ա�', 'combobox', null, 'commonCombobox_sex', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'insureidenddate1', 'insureidenddate', '֤����Чֹ��', 'databox', null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredbirthday1', 'lcinsuredbirthday', '��������', 'databox', null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsurednativeplace1', 'lcinsurednativeplace', '����', 'combobox', null, 'commonCombobox_country', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredroccupationcode1', 'lcinsuredroccupationcode', 'ְҵ����', 'combobox', null, 'commonCombobox_occupationcodemulti', null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'insuredpostcity1', 'postcity', '��ַ��', 'combobox', null, 'commonCombobox_insuredpostcitymulti', null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'postaladdress1', 'postaladdress', '��ϸ��ַ', null, null, null, null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'zipcode1', 'zipcode', '��������', null, null, null, null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'rgtaddress1', 'rgtaddress', '����������(��Ԫ)', null, null, null, null, 'lcinsuredmulti', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredtwocountrycode_anzl', 'countrycodetel_tel', '�̶��绰���Ҵ���', 'combobox', null, 'commonCombobox_countrycode_anzl', null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinusredtwoareacode_tel', 'areacodetel', '�̶��绰����', null, null, null, null, 'lcaddress', null, null);
insert into FORMELEMENT (sid, id, name, text, type, englishtext, checkboxoption, cssclass, groupid, parentid, noticeelementgroup)
values ('lcinsuredmulti', 'lcinsuredtwocountrycode_anzl1', 'countrycodetel_mob', '�ƶ��绰���Ҵ���', 'combobox', null, 'commonCombobox_countrycode_anzl', null, 'lcaddress', null, null);
prompt 29 records loaded
set feedback on
set define on
prompt Done.
