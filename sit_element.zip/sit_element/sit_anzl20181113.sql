prompt PL/SQL Developer import file
prompt Created on 2018��11��13�� by chen
set feedback off
set define off
prompt Loading ELEMENTSOFCONTROL...
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'zipcode1', null, '{"notEmpty":null}', null, 91, '01', 'N/A', 'address', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'insuredpostprovince1', null, '{"notEmpty":null}', null, 85, '01', 'N/A', 'address', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'insuredpostcity1', null, '{"notEmpty":null}', null, 86, '01', 'N/A', 'address', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'postaladdress1', null, '{"notEmpty":null}', null, 90, '01', 'N/A', 'address', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'insuredpostdistrict1', null, '{"notEmpty":null}', null, 87, '01', 'N/A', 'address', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredtwocountrycode_anzl', null, null, null, 95, '01', 'N/A', 'phone', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinusredtwoareacode_tel', null, null, null, 96, '01', 'N/A', 'phone', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredtwocountrycode_anzl1', null, '{"notEmpty":null}', null, 98, '01', 'N/A', 'phone', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'mobile1', null, '{"notEmpty":null}', null, 99, '01', 'N/A', 'phone', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'phone1', null, null, null, 97, '01', 'N/A', 'phone', null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredroccupationcode1', null, '{"notEmpty":null}', null, 71, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredcompany1', null, '{"notEmpty":null}', null, 61, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'insureidenddate1', null, '{"notEmpty":null,"date": {}}', null, 57, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredbirthday1', null, '{"notEmpty":null,"date": {}}', null, 58, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsurednativeplace1', null, '{"notEmpty":null}', null, 59, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'email1', null, null, null, 64, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'rgtaddress1', null, '{"notEmpty":null,"digits":null}', null, 65, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'relatoinsu1', null, '{"notEmpty":null}', null, 52, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredtype1', null, '{"notEmpty":null}', null, 68, '02', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredindustry1', null, '{"notEmpty":null}', null, 69, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredindustrycode1', null, '{"notEmpty":null}', null, 70, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredidtype1', null, '{"notEmpty":null}', null, 54, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredidno1', null, '{"notEmpty":null}', null, 55, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredsex1', null, '{"notEmpty":null}', null, 56, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredbirthcounty1', null, '{"notEmpty":null}', null, 60, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'relationtoappnt1', null, '{"notEmpty":null}', null, 51, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredname1', null, '{"notEmpty":null}', null, 53, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'coveredlocalsociomedical1', null, '{"notEmpty":null}', null, 89, '01', 'N/A', null, null);
insert into ELEMENTSOFCONTROL (sid, id, defaultvalue, validitem, relateobjectfield, comorder, elementstatus, combinedid, subsid, cssclass)
values ('lcinsuredmulti', 'lcinsuredtwojade', null, '{"notEmpty":null}', null, 72, '01', 'N/A', null, null);
prompt 29 records loaded
set feedback on
set define on
prompt Done.
